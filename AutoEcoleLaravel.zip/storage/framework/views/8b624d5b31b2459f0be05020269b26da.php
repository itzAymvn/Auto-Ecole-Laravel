 <!-- Start of copyright section -->
 <div class="container-fluid copyright text-light py-4">
     <div class="container">
         <div class="row">
             <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                 &copy; <a href="#">Auto-école</a>, All Right Reserved.
             </div>
         </div>
     </div>
 </div>
 <!-- End of copyright section -->

 <!-- Back to Top Button -->
 <a href="#" class="btn btn-lg btn-primary btn-lg-square d-flex align-items-center back-to-top"><i
         class="bi bi-arrow-up"></i></a>
<?php /**PATH C:\Users\Ayman\Desktop\AutoEcoleLaravel\resources\views/layout/footer.blade.php ENDPATH**/ ?>